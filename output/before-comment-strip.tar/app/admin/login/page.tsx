import { redirect } from "next/navigation";

/** Admins log in like everyone else — email code (or Google) at /login — then come straight back here.
 *  Admin access comes from the account's role ("admin" in Neon Auth), not from a password. */
export default function AdminLogin() {
  redirect("/login?next=/admin/orders");
}
